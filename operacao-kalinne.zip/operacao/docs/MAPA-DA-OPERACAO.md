# Mapa da operação — método do Elton Luiz, aplicado

> Consolidação de tudo que a aula ensinou, virado em plano executável.
> Negócio de uma pessoa só, tocado por agentes de IA.

---

## A tese central

A IA não cria o que você não sabe. Ela lê o que você já criou e multiplica por
dez. Todo agente desta operação obedece a isso: eles só falam o que a Kalinne
já falou, do jeito que ela fala, embasados nas técnicas de marketing que ela
escolheu colocar na base.

O ciclo do negócio é curto e repetível: **arruma, lança, arruma, lança** — a
cada 30 ou 40 dias.

---

## A arquitetura de ferramentas

| Ferramenta | Papel na aula | Status |
|---|---|---|
| **Claude (plano pago + Claude Code)** | O cérebro. Onde os agentes rodam. | ✅ pronto |
| **Supabase** | O coração pulsante. Transcrições, base de conhecimento dos agentes, leads, clientes — tudo que importa do negócio. | ✅ banco montado |
| **Vercel** | Todas as páginas: vendas, captura, pop-ups, fichas de inscrição, pesquisas, dashboards. | ✅ conta criada |
| **GitHub** | O "Google Drive da programação". Onde ficam as pastas dos agentes, para trabalhar de qualquer máquina e distribuir para outras pessoas. | ✅ conta criada |
| Claude Design | Deixa a página bonita. Handoff para o Claude Code publicar no Vercel. | usar no passo 6 |
| E-mail marketing | Cano de saída da comunicação. Recebe segmentos do Supabase. | a escolher |
| WhatsApp | Grupo do evento + régua de lembretes. | a escolher |
| Checkout | Carrinho. Manda a venda de volta para o Supabase. | a escolher |
| Área de membros | Entrega do produto. | a escolher |

---

## Os 7 passos

### Passo 1 — Infraestrutura ✅

Claude com plano pago e instalado na máquina, Supabase, Vercel e GitHub. As
três últimas são gratuitas para começar. A única que se paga é o Claude, e o
custo-benefício justifica.

**Feito:** banco montado com 13 tabelas, RLS ligado, registro dos agentes
populado.

### Passo 2 — Posicionamento: criar o próprio nicho

Simples de explicar, difícil de executar. O trabalho não é escolher um nicho
menor — é **nomear uma categoria de mercado que ninguém ocupa**. Foi assim que
"negócio de uma pessoa só" nasceu em 2023.

Como se faz:

1. Encontrar PDFs e livros dos grandes marqueteiros de posicionamento
   (Al Ries inventou o termo — comece por ele).
2. Ensinar a skill **markitdown** (da Microsoft) para o Claude. Ela converte
   qualquer arquivo — PDF, MP4, DOCX — em `.md`, que é o formato que a IA lê
   melhor e mais barato.
3. Jogar tudo convertido na base de dados.
4. Criar o **agente de posicionamento**, que lê esse material e ajuda a
   encontrar e nomear a categoria desocupada.

Quando você acha a categoria vazia, **o diferencial aparece sozinho**.

> Agente: `posicionamento` · Skill: `markitdown` · Tabelas: `fontes` → `posicionamento`

### Passo 3 — Escrever e gravar todos os dias

Todo dia sai material — vídeo, áudio, texto, não importa o canal. Esse
material é a matéria-prima de tudo.

Um **agente transcritor** converte tudo em texto. Um **agente de tom de voz**
destila as transcrições no jeito de falar da Kalinne. É esse perfil que todos
os outros agentes vão usar.

> Agentes: `transcritor`, `tom-de-voz` · Tabelas: `transcricoes` → `tom_de_voz`

### Passo 4 — A máquina de conteúdo

Antes: gravar o vídeo, escrever o carrossel, fazer o roteiro, gravar os Reels —
tudo na mão.

Agora: grava o vídeo → o transcritor transcreve → aquilo vira tom de voz →
outros agentes transformam em carrossel, e-mail, roteiro, anúncio.

A máquina de conteúdo tem que partir dela. Nenhum agente fala o que ela nunca
falou.

> Agente: `conteudo` · Tabela: `conteudos`

### Passo 5 — Criar o produto

Se precisa de dinheiro agora: **serviço** (troca hora por dinheiro) ou
**mentoria / atendimento 1 a 1** (alto valor agregado). O que escala é o
infoproduto — mas ele vem depois, ou em paralelo.

Dois formatos recomendados, escolha um:

- **Workshop / masterclass / imersão** — 2 horas, ao vivo, repetível.
- **Curso de 7 aulas em 7 dias** — curto, fácil de explicar, fácil de entender.

O produto nasce da combinação: PDFs de marketing na base **+** as transcrições
dela. A pergunta para o agente é literalmente *"o que eu deveria vender, com
base em tudo que eu já criei e nas técnicas desses livros?"*.

Depois, alimente o agente com um livro de **oferta** — `$100M Offers` ou
`Startup de $X` — e peça a oferta.

> Agente: `produto-oferta` · Tabelas: `fontes` + `transcricoes` + `posicionamento` → `produtos`, `ofertas`

### Passo 6 — Páginas e infraestrutura de venda

A parte mais fácil, porque a essa altura você já tem tom de voz, produto, base
de dados e Vercel.

O fluxo:

```
Página de captura ──▶ Grupo de WhatsApp ──▶ Evento
                                              │
                     Página de vendas ◀───────┘
                            │
                      Pop-up (nome, telefone, e-mail)
                            │
                        Checkout
                            │
                     Área de membros
```

**Página de captura: duas dobras, só.** Promessa do evento na primeira; vídeo
ou foto dela + formulário com nome, telefone e e-mail na segunda.

Todos esses dados caem no Supabase. De lá, a IA distribui para a plataforma de
e-mail marketing e de WhatsApp, entendendo quem é cliente e quem não é — para
falar **de venda com quem não comprou** e **de retenção com quem já comprou**.

Como fazer a página ficar bonita: peça a copy ao Claude → peça um prompt de
design → jogue no Claude Design → botão de handoff para o Claude Code →
publique no Vercel.

> Agentes: `paginas`, `crm` · Tabelas: `leads`, `clientes`

### Passo 7 — O lançamento

```
D-14  começa a captação (anúncios → página de captura → grupo de WhatsApp)
D-0   EVENTO com dia e hora (ao vivo ou gravado, tanto faz)
      no fim do evento, anuncia a venda → abre o carrinho
D+1..D+4  vende
D+5   FECHAMENTO DO CARRINHO ← o dia que mais vende
```

Os anúncios: texto e imagem feitos com IA, vídeo gravado por ela (dá para
criar um agente que edita os vídeos depois).

Mesmo que não venda nada no primeiro, você aprendeu a rodar uma operação
digital. Aí arruma e lança de novo.

> Agente: `lancamento` · Tabelas: `eventos`, `lancamentos`, `sequencias_email`

---

## O escritório de agentes

| # | Agente | O que faz | Passo |
|---|---|---|---|
| 1 | `posicionamento` | Acha e nomeia a categoria desocupada | 2 |
| 2 | `transcritor` | Converte tudo em markdown e grava no banco | 3 |
| 3 | `tom-de-voz` | Destila as transcrições no jeito de falar dela | 3 |
| 4 | `conteudo` | Um material vira dez peças | 4 |
| 5 | `produto-oferta` | Concebe o infoproduto e monta a oferta | 5 |
| 6 | `paginas` | Captura, vendas, dashboards, publica no Vercel | 6 |
| 7 | `crm` | Segmenta comprador vs. não-comprador, sincroniza canais | 6 |
| 8 | `lancamento` | Cronograma, e-mails, anúncios, régua de WhatsApp | 7 |

---

## O que continua sendo humano

- **Gravar.** A voz é dela. Nenhum agente substitui isso.
- **Decidir o posicionamento.** O agente propõe três, ela escolhe.
- **Tráfego pago.** Vale terceirizar enquanto não existe agente para isso.
- **Comercial no lançamento.** Em lançamentos maiores, compensa um freelancer
  de vendas durante o período de carrinho aberto.

O resto roda sozinho.
