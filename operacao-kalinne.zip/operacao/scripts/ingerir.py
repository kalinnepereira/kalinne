#!/usr/bin/env python3
"""
Ingere arquivos markdown na base de conhecimento do Supabase.

Uso:
    python scripts/ingerir.py fonte  base-de-conhecimento/livros/*.md
    python scripts/ingerir.py transcricao base-de-conhecimento/transcricoes/*.md

Requer no .env:
    SUPABASE_URL=https://xjeviicorkzusnvglduc.supabase.co
    SUPABASE_SERVICE_ROLE_KEY=...
"""
import os
import re
import sys
from datetime import date
from pathlib import Path

try:
    from dotenv import load_dotenv
    from supabase import create_client
except ImportError:
    sys.exit("Faltam dependências. Rode: pip install -r scripts/requirements.txt")

load_dotenv()

URL = os.environ.get("SUPABASE_URL")
KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
if not URL or not KEY:
    sys.exit("Configure SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY no .env")

db = create_client(URL, KEY)

DATA_NO_NOME = re.compile(r"^(\d{4}-\d{2}-\d{2})-")


def titulo_de(caminho: Path, texto: str) -> str:
    for linha in texto.splitlines():
        if linha.startswith("# "):
            return linha[2:].strip()
    return caminho.stem.replace("-", " ").strip()


def data_de(caminho: Path):
    m = DATA_NO_NOME.match(caminho.stem)
    return m.group(1) if m else date.today().isoformat()


def ingerir(tipo: str, caminhos: list[str]) -> None:
    tabela = "fontes" if tipo == "fonte" else "transcricoes"
    for c in caminhos:
        p = Path(c)
        if not p.is_file():
            print(f"  pulado (não é arquivo): {c}")
            continue
        texto = p.read_text(encoding="utf-8")
        titulo = titulo_de(p, texto)

        ja_existe = db.table(tabela).select("id").eq("titulo", titulo).execute()
        if ja_existe.data:
            print(f"  já existe, pulando: {titulo}")
            continue

        if tabela == "fontes":
            linha = {
                "titulo": titulo,
                "tipo": "livro",
                "categoria": "marketing",
                "conteudo_md": texto,
            }
        else:
            linha = {
                "titulo": titulo,
                "origem": "aula",
                "data_gravacao": data_de(p),
                "transcricao": texto,
            }

        db.table(tabela).insert(linha).execute()
        print(f"  ingerido em {tabela}: {titulo} ({len(texto):,} caracteres)")


if __name__ == "__main__":
    if len(sys.argv) < 3 or sys.argv[1] not in ("fonte", "transcricao"):
        sys.exit(__doc__)
    print(f"Ingerindo {len(sys.argv) - 2} arquivo(s) como '{sys.argv[1]}'...")
    ingerir(sys.argv[1], sys.argv[2:])
    print("Pronto. Revise resumo, temas e categoria no Supabase.")
