# Operação Kalinne

Escritório de agentes de IA para tocar um negócio digital de uma pessoa só.

## O que tem aqui

```
.claude/
  agents/           os 8 agentes
  skills/markitdown/ conversão de qualquer arquivo para markdown
base-de-conhecimento/
  brutos/           arquivos originais (PDF, MP4) — não vai pro GitHub
  livros/           material de terceiros já em .md
  transcricoes/     material da Kalinne já em .md
scripts/
  ingerir.py        joga os .md dentro do Supabase
docs/
  MAPA-DA-OPERACAO.md   o plano completo dos 7 passos
CLAUDE.md           regras que todo agente obedece
```

## Como começar em uma máquina nova

```bash
git clone <url-do-repo>
cd operacao
cp .env.example .env      # e preencha as chaves
pip install -r scripts/requirements.txt
claude
```

## Rotina diária

1. Gravar ou escrever alguma coisa.
2. Jogar o arquivo em `base-de-conhecimento/brutos/`.
3. `claude` → pedir para o agente `transcritor` ingerir.
4. Pedir para o agente `conteudo` transformar em carrossel, e-mail e roteiro.
5. Aprovar o que for publicar.

## Onde ficam as chaves do Supabase

Supabase → projeto `kalinnecruz` → Project Settings → API Keys.
A `service_role` só vive no `.env` local. Nunca no front, nunca no GitHub.
