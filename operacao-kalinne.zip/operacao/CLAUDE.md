# Operação Digital — Kalinne

Este repositório é o escritório de agentes de IA da Kalinne. Todo agente que roda
aqui trabalha para uma operação de uma pessoa só: posicionamento, máquina de
conteúdo, produto, páginas e lançamento.

## Princípio inegociável

**Nenhum agente inventa opinião.** Todo conteúdo sai do que a Kalinne já falou
(tabela `transcricoes`) no tom dela (tabela `tom_de_voz`), embasado nas técnicas
dos materiais que ela escolheu (tabela `fontes`). A IA não cria o que ela não
sabe — ela multiplica por 10 o que ela já criou.

## Onde ficam as coisas

| Camada | Ferramenta | Papel |
|---|---|---|
| Dados | Supabase (`kalinnecruz`, `sa-east-1`) | Coração. Conhecimento, conteúdo, produtos, leads, clientes. |
| Páginas | Vercel | Captura, vendas, obrigado, dashboards. |
| Código | GitHub | Este repositório. Portabilidade entre máquinas. |
| Cérebro | Claude Code | Os agentes em `.claude/agents/`. |

## Banco de dados

Projeto Supabase: `xjeviicorkzusnvglduc`

| Tabela | Para quê |
|---|---|
| `fontes` | Livros e PDFs de marketing convertidos em markdown. |
| `transcricoes` | Tudo que a Kalinne grava ou escreve, transcrito. |
| `tom_de_voz` | Perfil de voz destilado. Só um registro `ativo = true`. |
| `posicionamento` | Candidatos de categoria desocupada. Só um `status = 'ativo'`. |
| `conteudos` | Carrosséis, e-mails, roteiros, anúncios. |
| `produtos` / `ofertas` | O infoproduto e a oferta. |
| `eventos` / `lancamentos` / `sequencias_email` | A máquina de lançamento. |
| `leads` / `clientes` | Público. Quem não comprou vs. quem comprou. |
| `agentes` | Registro do próprio escritório. |

RLS está ligado em tudo. Só a `service_role` lê e escreve — exceto `leads`,
que aceita `insert` anônimo para os formulários de captura funcionarem.

## Regras para qualquer agente deste repositório

1. Antes de gerar conteúdo, **leia o `tom_de_voz` ativo**. Sem exceção.
2. Antes de posicionar, produto ou copy, **leia o `posicionamento` ativo**.
3. Grave o resultado no Supabase. Arquivo solto na pasta não é entrega.
4. Português do Brasil, sempre. Sem jargão de marketing gringo não traduzido.
5. Nunca escreva credenciais em arquivo versionado. Use `.env` (que está no
   `.gitignore`).
6. Se faltar matéria-prima (transcrição, fonte, posicionamento), **pare e peça**
   em vez de inventar.

## Ordem de construção (os 7 passos)

1. Infraestrutura — Supabase + Vercel + GitHub + Claude Code ✅
2. Posicionamento — encontrar a categoria desocupada
3. Máquina de conteúdo — transcrever, extrair tom de voz, multiplicar
4. Produto — workshop de 2h ou curso de 7 aulas em 7 dias
5. Oferta — construída sobre as técnicas dos livros da base
6. Páginas e infraestrutura de venda — captura → pop-up → checkout → área de membros
7. Lançamento — evento com data e hora, 3 a 5 dias de carrinho, fecha no último dia
