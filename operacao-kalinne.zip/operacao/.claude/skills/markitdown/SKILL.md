---
name: markitdown
description: Converte qualquer arquivo (PDF, DOCX, PPTX, XLSX, MP3, MP4, HTML, imagem) em Markdown para alimentar a base de conhecimento. Use ao ingerir livros, aulas, e-mails antigos ou qualquer material bruto.
---

# markitdown — tudo vira Markdown

Markdown é o formato que a IA lê melhor e mais barato. PDF não é. MP4 não é.
Antes de qualquer material entrar na base, ele passa por aqui.

## Instalação (uma vez só)

```bash
pip install 'markitdown[all]'
```

Para áudio e vídeo com transcrição de fala:

```bash
pip install openai-whisper
# ou, mais rápido:
pip install faster-whisper
```

## Uso

```bash
# um arquivo
markitdown livro.pdf > base-de-conhecimento/livros/livro.md

# uma pasta inteira
for f in base-de-conhecimento/brutos/*; do
  markitdown "$f" > "base-de-conhecimento/livros/$(basename "${f%.*}").md"
done
```

Formatos suportados: PDF, DOCX, PPTX, XLSX, CSV, HTML, EPUB, ZIP, imagens
(com OCR), áudio e vídeo (com transcrição).

## Depois de converter

1. **Confira a conversão.** PDF escaneado às vezes sai embaralhado. Se saiu
   ruim, rode com OCR ou converta de novo a partir de outra fonte.
2. **Limpe.** Tire sumário, numeração de página, rodapé repetido, cabeçalho.
3. **Ingira no Supabase** — material de terceiros vai para `fontes`, material
   da Kalinne vai para `transcricoes`. Use `scripts/ingerir.py`.

## Convenção de nomes

```
base-de-conhecimento/livros/autor-titulo.md
base-de-conhecimento/transcricoes/AAAA-MM-DD-titulo-slug.md
```

## O que vale a pena ingerir

- Livros e PDFs de posicionamento (Al Ries, Jack Trout e afins)
- Livros de oferta (`$100M Offers`, `Startup de $X` e afins)
- Materiais de copy e lançamento
- **Tudo** que a Kalinne já gravou, escreveu ou ensinou
