---
name: paginas
description: Gera e publica páginas de captura, vendas, obrigado e dashboards no Vercel. Use ao criar qualquer página do funil.
---

# Agente de Páginas

Você constrói o que o público vê. Tudo vai para o Vercel, tudo grava lead no
Supabase.

## O funil completo

```
Anúncio → Página de captura → Grupo de WhatsApp → Evento
                                                    ↓
                          Página de vendas → Pop-up (nome, telefone, e-mail)
                                                    ↓
                                              Checkout → Área de membros
```

Cada formulário do funil grava em `leads`. Cada compra grava em `clientes`.

## Página de captura — exatamente duas dobras

**Dobra 1:** a promessa do evento (headline + subheadline + data e hora).
**Dobra 2:** vídeo dela explicando o evento (ou foto) + formulário com nome,
telefone e e-mail.

Nada além disso. Sem menu, sem rodapé com links, sem depoimento, sem FAQ.
A única saída é o formulário. Depois do envio → redireciona para o grupo de
WhatsApp.

## Página de vendas

Estrutura base (ajuste pela oferta em `ofertas`):

1. Headline + promessa
2. Para quem é / para quem não é
3. O problema, nomeado do jeito que o público nomeia
4. O mecanismo único
5. O que está incluso (grade de aulas)
6. Bônus
7. Prova (o que ela já fez, o que já ensinou)
8. Preço e ancoragem
9. Garantia
10. Objeções (FAQ)
11. CTA final + escassez real (data de fechamento)

## Como construir

1. Escreva a copy lendo `ofertas`, `produtos` e o `tom_de_voz` ativo.
2. Peça um **prompt de design** a partir da copy e leve para o Claude Design.
   Traga o resultado de volta com o handoff para código.
3. Publique no Vercel.
4. Guarde a URL em `ofertas.pagina_vendas_url` ou
   `eventos.pagina_captura_url`.

## Técnico

- Stack: Next.js (App Router) + Tailwind. Uma página = uma rota.
- Formulários usam a chave **publishable/anon** do Supabase e inserem em
  `leads` (existe policy de insert anônimo para isso). **Nunca** exponha a
  `service_role` no front.
- Sempre capture UTM na query string e grave em `leads.utm`.
- Mobile primeiro. A maior parte do tráfego vem do celular.
- Teste o formulário antes de entregar: insira um lead de teste, confirme no
  banco, apague o teste.

## Dashboard

Uma rota protegida com: leads por dia, origem do lead, taxa de conversão da
captura, vendas do lançamento aberto, faturamento vs. meta. Lê de `leads`,
`clientes` e `lancamentos`.
